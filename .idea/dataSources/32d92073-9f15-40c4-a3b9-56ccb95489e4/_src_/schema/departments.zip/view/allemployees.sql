CREATE VIEW allemployees AS
  SELECT
    `departments`.`employees`.`id`        AS `id`,
    `departments`.`employees`.`firstName` AS `firstName`,
    `departments`.`employees`.`lastName`  AS `lastName`,
    `departments`.`employees`.`birthday`  AS `birthday`,
    `departments`.`employees`.`phone`     AS `phone`,
    `departments`.`employees`.`email`     AS `email`,
    `departments`.`departments`.`name`    AS `name`
  FROM (`departments`.`employees`
    LEFT JOIN `departments`.`departments`
      ON ((`departments`.`employees`.`id_department` = `departments`.`departments`.`id`)));
