CREATE VIEW alldepartments AS
  SELECT
    `departments`.`departments`.`id`   AS `id`,
    `departments`.`departments`.`name` AS `name`
  FROM `departments`.`departments`;
